from pymongo import MongoClient
# from bson.objectid import ObjectId


class AnimalShelter(object):
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(
        self,
        user="aacuser",
        password="SNHU1234",
        host="localhost",
        port=27017,
        db="aac",
        collection="animals"
    ):
        """Initialize the MongoDB connection."""

        self.client = MongoClient(
            f"mongodb://{user}:{password}@{host}:{port}"
        )

        self.database = self.client[db]
        self.collection = self.database[collection]

    def read_next(self):
        """Return the next available record number."""

        last_record = self.collection.find_one(
            sort=[("rec_num", -1)]
        )

        if last_record is None:
            return 1

        return last_record["rec_num"] + 1

    def create(self, data):
        """Insert a document and return True if successful."""

        if data is None:
            raise Exception(
                "Nothing to save, because data parameter is empty"
            )

        result = self.collection.insert_one(data)
        return result.acknowledged

    def read(self, data):
        if data is not None:
            return list(
                self.database.animals.find(data, {"_id": False})
            )

        else:
            return []

    def update(self, query, update_data):
        """Update a document and return True if successful."""

        if query is None or update_data is None:
            return 0
        try:
            result = self.collection.update_many(query, {"$set": update_data})
            return result.modified_count
        except Exception as e:
            return 0

    def delete(self, data):
        """Delete a document and return True if successful."""

        if data is None:
            return 0
        try:
            result = self.collection.delete_many(data)
            return result.deleted_count
        except Exception as e:
            return 0
